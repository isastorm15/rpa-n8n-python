def classificar_solicitacao(mensagem: str) -> str:
    """Classifica uma solicitação de atendimento por palavras-chave."""
    texto = (mensagem or "").lower()

    if any(palavra in texto for palavra in ["acesso", "senha", "login", "entrar"]):
        return "Suporte de Acesso"

    if any(palavra in texto for palavra in ["pagamento", "cobrança", "boleto", "fatura"]):
        return "Financeiro"

    if any(palavra in texto for palavra in ["erro", "falha", "problema", "bug"]):
        return "Suporte Técnico"

    return "Atendimento Geral"


if __name__ == "__main__":
    exemplo = "Estou com dificuldade para acessar minha conta."
    print(classificar_solicitacao(exemplo))
